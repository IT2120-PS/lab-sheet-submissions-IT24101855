setwd("C:\\Users\\IT24101855\\Desktop\\IT24101855")
getwd()
pbinom(46,50,0.85,lower.tail = FALSE)
dpois(15,12)

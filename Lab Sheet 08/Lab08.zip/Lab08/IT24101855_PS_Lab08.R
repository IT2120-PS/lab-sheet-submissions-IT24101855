setwd("C:\\Users\\thine\\OneDrive\\Desktop\\Lab08")
getwd()
data <- read.table("Exercise - LaptopsWeights.txt",header = TRUE)
fix(data)
attach(data)
popmean<-mean(Weight.kg.)
popmean
popsd<-sd(Weight.kg.)
popsd

samples<-c()
n <- c()

for(i in 1:25){
  s<-sample(Weight.kg.,6,replace = TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('S',i))
}
colnames(samples)=n
s.mean <- apply(samples,2,mean)
s.mean
s.sd <- apply(samples,2,sd)
s.sd
samplemean<-mean(s.mean)
samplesd<- sd(s.sd)

popmean
samplemean

truesd <-popsd/sqrt(6)
truemean <- popmean

samplemean
truemean

samplesd
truesd

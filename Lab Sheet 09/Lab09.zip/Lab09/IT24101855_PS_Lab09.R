setwd("C:\\Users\\thine\\OneDrive\\Desktop\\Lab09")
getwd()
y<- rnorm(25,mean=45,sd=2)
print(y)


t.test(y, mu = 46, alternative = "less")
